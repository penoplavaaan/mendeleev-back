<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
    <script
            src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
            crossorigin="anonymous"></script>
    <script src="js/index.js"></script>
    <title>Document</title>
</head>
<body>
<div class="container" id="body">
    <?php
    include 'ImageGallery.php';
    $gallery = new ImageGallery("img");
    $gallery ->printTable();
    ?>
</div>

<script>
    $( document ).ready(function (){
        $('#bttn-1').css( "background-color", "#6c757d" );
        $('#bttn-1').css( "color", "white" );
    })
    function deleteImage(name){
        $.ajax({
            method: "GET",
            data: {"name":name},
            url: './delete.php',
            success: function(data) {
                alert('Element deleted successfully');
                console.log(data);
                $('#body').html(data);
            }
        });
    }

    function changePage(pageNum){

        $.ajax({
            method: "GET",
            data: {"pageNum":pageNum},
            url: './change.php',
            success: function(data) {
                console.log(data);
                $('#body').html(data);
                $('#bttn-'+pageNum).css( "background-color", "#6c757d" );
                $('#bttn-'+pageNum).css( "color", "white" );
            }
        });
    }
</script>


</body>
</html>

